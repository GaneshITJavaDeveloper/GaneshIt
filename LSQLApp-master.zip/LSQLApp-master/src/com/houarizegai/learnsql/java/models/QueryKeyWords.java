package com.houarizegai.learnsql.java.models;

import java.util.List;
import java.util.Map;

public class QueryKeyWords {

    public static List<String> tableNames;
    public static List<String> columnNames;
    public static Map<Integer, String[]> keywords; // keywords sql - natural
    public static List<String> hintKeyword;
    
}
